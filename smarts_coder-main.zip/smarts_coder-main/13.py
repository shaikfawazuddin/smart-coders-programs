n = int(input())
print('n << 1 =', n << 1)
print('n >> 1 =', n >> 1)
