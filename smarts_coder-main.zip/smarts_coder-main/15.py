print(bin(int(input())).count('1'))
